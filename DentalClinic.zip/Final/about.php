<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <!--fond cdn-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!--end-->
    <!--bootstrap cdn-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<!--end-->
<!--css link-->
<link rel="stylesheet" href="style.css">
</head>
<body>
    <!--header section-->
<nav class="navbar fixed-top">
  <div class="container-fluid">
    
      <a class="logo" href="#home">Dentanl<span>Care.</span></a>
    <div class="nav">
      <a href="#home">Home</a>
      <a href="#about">About Us</a>
      <a href="#services">Services</a>
      <a href="#reviews">Reviews</a>
      <a href="#contact">Contact</a>
    </div>
    <a href="#contact" class="link-btn">Make Appointment</a>
 <div id="menu-btn" class="fas fa-bars"></div>
</div>

</nav>
<!--Home start-->
<section class="home" id="home">
    <div class="container">
        <div class="row min-vh-100 align-items-center">
        <div class="content text-center text-md-left">
            <h1>About Us</h1>
            
        </div>
        </div>
    </div>
</section>
<!--end-->
<!--about section-->
<section class="about" id="about">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 image">
                <img src="about.jpg" class="w-100 mb-4 mb-md-0" alt="">
            </div>
            <div class="col-md-6 content">
                <span>About Us</span>
                <h3>True Healthcare For Your Family</h3>
                <p>"True healthcare for your family goes beyond treating illnesses; it embraces a holistic approach to well-being. It involves fostering a supportive environment, promoting preventive care, and nurturing both physical and mental health. True healthcare is a commitment to understanding each family member's unique needs and actively working towards their overall wellness. It's a journey that prioritizes empathy, communication, and a shared dedication to a healthy, happy life together."</p>
                <a href="#contact" class="link-btn">Make Appointment</a>
            </div>
        </div>
    </div>
</section>
<!--end-->
</body>
</html>